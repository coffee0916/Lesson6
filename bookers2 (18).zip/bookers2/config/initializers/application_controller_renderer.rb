# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '9bd9dc34013f63264e129c381ea7abecff644af3b8b89c0288448ff703f9a47cd5102c5ffa11277e34b33350c7501308bf6d594c365f9c8537746810bc868015'